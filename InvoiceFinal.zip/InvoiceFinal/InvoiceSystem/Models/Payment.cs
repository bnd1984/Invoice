﻿namespace InvoiceSystem.Models
{
    public class Payment
    {
        public decimal Amount { get; set; }
    }
}

