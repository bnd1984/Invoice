﻿namespace InvoiceSystem.Models
{
    public class InvoiceRequest
    {
        public decimal Amount { get; set; }
        public DateTime DueDate { get; set; }
    }
}

